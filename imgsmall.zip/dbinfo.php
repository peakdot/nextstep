<?php
$servername = "localhost";
$username = "root";
$pw = "admin";
$dbname = "nextstep";
?>